export class SearchDetails{
    constructor(
        public  searchKey: string,
        public  searchValue: string,
        
              ){}
}